# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree.

"""OpenEnv CLI - Command-line tool for managing OpenEnv environments."""

__version__ = "0.1.0"
